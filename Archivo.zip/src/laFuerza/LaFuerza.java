package laFuerza;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;

public class LaFuerza {

//	private LinkedList<Usuario> usuarios = new LinkedList<Usuario>();
//	private LinkedList<Propuesta> propuestas = new LinkedList<Propuesta>();
//	private int cuposTotales = 0;
	private int cantidadUsuariosCompradores = 0;
	private int totalCuposDisponibles = 0;
	private int maximoVentasNoConcretadas = 0;

	public void agregarAtracciones(List<String> atraccionesAIngresar) {
		for (String atraccion : atraccionesAIngresar) {
			String[] datosAtracciones = atraccion.split(",");
			String nombre = datosAtracciones[0].trim();
			int costo = Integer.parseInt(datosAtracciones[1].trim());
			double tiempo = Double.parseDouble(datosAtracciones[2].trim());
			int cupo = Integer.parseInt(datosAtracciones[3].trim());
			TipoAtraccion tipoAtraccion = TipoAtraccion.valueOf(datosAtracciones[4].trim());

			Atraccion nuevaAtraccion = new Atraccion(costo, tiempo, tipoAtraccion, cupo, nombre);
			propuestas.add(nuevaAtraccion);
			cuposTotales += cupo;
		}

	}

	public void agregarPromociones(List<String> promocionesAIngresar) {

		for (String promocion : promocionesAIngresar) {
			String[] datosPromociones = promocion.split(",");
			TipoPromocion tipoPromocion = TipoPromocion.valueOf(datosPromociones[0].trim());
			TipoAtraccion tipoAtraccion = TipoAtraccion.valueOf(datosPromociones[1].trim());
			String nombre = datosPromociones[2].trim();
			String descripcion = datosPromociones[3].trim();

			String[] atraccionesString = datosPromociones[5].split(";");
			LinkedList<Atraccion> atracciones = new LinkedList<Atraccion>();
			for (int i = 0; i < atraccionesString.length; i++) {
				atracciones.add(this.obtenerAtraccionPorNombre(atraccionesString[i].trim()));
			}

			Promocion nuevaPromocion;
			if (tipoPromocion == TipoPromocion.PORCENTUAL) {
				Double porcentajeDescuento = Double.parseDouble(datosPromociones[4].trim());
				nuevaPromocion = new PromoPorcentual(tipoAtraccion, nombre, descripcion, atracciones,
						porcentajeDescuento);
			} else if (tipoPromocion == TipoPromocion.ABSOLUTA) {
				int costoTotal = Integer.parseInt(datosPromociones[4].trim());
				nuevaPromocion = new PromoAbsoluta(tipoAtraccion, nombre, descripcion, atracciones, costoTotal);
			} else {
				LinkedList<Atraccion> atraccionesGratis = new LinkedList<Atraccion>();
				String[] atraccionesGratsString = datosPromociones[4].split(";");
				for (int i = 0; i < atraccionesGratsString.length; i++) {
					atraccionesGratis.add(this.obtenerAtraccionPorNombre(atraccionesGratsString[i].trim()));
				}

				nuevaPromocion = new PromocionAXB(tipoAtraccion, nombre, descripcion, atracciones, atraccionesGratis);
			}
			propuestas.add(nuevaPromocion);
			nuevaPromocion.setCosto();
			nuevaPromocion.setTiempoUtilizado();

		}
	}

	public void agregarUsuarios(List<String> usuariosAIngresar) {

		for (String usuario : usuariosAIngresar) {
			String[] datosUsuarios = usuario.split(",");
			String nombre = datosUsuarios[0].trim();
			TipoAtraccion tipoAtraccion = TipoAtraccion.valueOf(datosUsuarios[1].trim());
			int costo = Integer.parseInt(datosUsuarios[2].trim());
			double tiempo = Double.parseDouble(datosUsuarios[3].trim());

			Usuario nuevoUsuario = new Usuario(nombre, tipoAtraccion, costo, tiempo);
			usuarios.add(nuevoUsuario);

		}

	}

	public void sugerirPropuestasAusuarios() throws IOException {
		LectorConsola.abrirEscanner();

		for (Usuario usuario : usuarios) {
			boolean comproPropuesta = false;
			List<Propuesta> propuestasOrdenadas = ordenarPropuestas(usuario.getTipoAtraccionPreferida());
			VisualizadorMensajesConsola.mostrarBienvenida(usuario);

			for (Propuesta propuesta : propuestasOrdenadas) {
				if (propuesta.hayCupoDisponible() && usuario.puedeAdquirirPropuesta(propuesta)) {
					VisualizadorMensajesConsola.ofrecerPropuesta(usuario, propuesta);
					if (usuario.aceptaPropuesta(propuesta)) {
						VisualizadorMensajesConsola.confirmaCompraPropuesta(propuesta);
						usuario.agregarPropuestaAceptada(propuesta);
						propuesta.actualizarCupoDisponible();
						propuesta.actualizarCompraPropuesta();
						comproPropuesta = true;
					} else {
						VisualizadorMensajesConsola.confirmaRechazoPropuesta(propuesta);
						propuesta.actualizarRechazoPropuesta();
					}
				}
			}
			GeneradorInerarioUsuario.escribirIntinerario(usuario);
			if (comproPropuesta) {
				cantidadUsuariosCompradores++;
				VisualizadorMensajesConsola.mostrarFinlizacionConCompra(usuario);
			} else {
				VisualizadorMensajesConsola.mostrarFinlizacionSinCompra(usuario);
			}
		}
		LectorConsola.cerrarEscanner();
		escribirResuemSistema();
	}

	private List<Propuesta> ordenarPropuestas(TipoAtraccion tipoAtraccion) {

		List<Propuesta> propuestasFiltradas = new ArrayList<Propuesta>();
		List<Propuesta> restoPropuestas = new ArrayList<Propuesta>();

		for (Propuesta propuesta : this.propuestas) {
			if (propuesta.getTipoAtraccion() == tipoAtraccion) {
				propuestasFiltradas.add(propuesta);
			} else {
				restoPropuestas.add(propuesta);
			}
		}

		Collections.sort(propuestasFiltradas);
		Collections.sort(restoPropuestas);
		propuestasFiltradas.addAll(restoPropuestas);

		return propuestasFiltradas;
	}

	private Atraccion obtenerAtraccionPorNombre(String nombre) {
		for (Propuesta atraccion : propuestas) {
			if (atraccion.getNombre().equals(nombre)) {
				return (Atraccion) atraccion;
			}
		}
		return null;
	}

	public LinkedList<Usuario> getUsuarios() {
		return usuarios;
	}

	public LinkedList<Propuesta> getPropuestas() {
		return propuestas;
	}

	private void escribirResuemSistema() throws IOException {
		GeneradorResumenSistema.escribirArchivosDetalle2(generarTablaDetallada(generarTablaOrdenada()));

//		GeneradorResumenSistema.escribirArchivosDetalle(armarTablaResumen());
		calcularTotalCuposDisponiblesyVentasNoConcretadas();
		GeneradorResumenSistema.escribirArchivoGeneral(totalCuposDisponibles, maximoVentasNoConcretadas, cuposTotales,
				cantidadUsuariosCompradores);

	}

	private Map<Integer, ArrayList<Propuesta>> generarTablaOrdenada() {
		
		Map<Integer, ArrayList<Propuesta>> propuestasContratadas = new TreeMap<Integer, ArrayList<Propuesta>>(
				Collections.reverseOrder());
		ArrayList<Propuesta> aux;

		for (Propuesta propuesta : propuestas) {

			Integer key = propuesta.getCosto() * propuesta.getCantidadComprada();
			if (propuestasContratadas.containsKey(key)) {
				aux = propuestasContratadas.get(key);
			} else {
				aux = new ArrayList<Propuesta>();
			}
			aux.add(propuesta);
			propuestasContratadas.put(key, aux);
		}
		return propuestasContratadas;

	}

	private String generarTablaDetallada(Map<Integer, ArrayList<Propuesta>> propuestasContratadas) {
		int totalIngresos = 0;
		int totalCompras = 0;
		int totalRechazos = 0;
		ArrayList<Propuesta> aux;

		String mensaje = "";
		mensaje += "Propuesta, Tipo de Atracción, Ingresos Totales, Compras, Rechazos\n";

		for (Entry<Integer, ArrayList<Propuesta>> cadaPropuesta : propuestasContratadas.entrySet()) {

			aux = cadaPropuesta.getValue();

			for (Propuesta propuesta : aux) {
				totalIngresos += cadaPropuesta.getKey();
				totalCompras += propuesta.getCantidadComprada();
				totalRechazos += propuesta.getCantidadRechazada();

				mensaje += propuesta.getNombre() + "," + propuesta.getTipoAtraccion().getNombre() + ","
						+ cadaPropuesta.getKey() + "," + propuesta.getCantidadComprada() + ","
						+ propuesta.getCantidadRechazada() + "\n";

			}

		}
		mensaje += "TOTALES" + ",," + totalIngresos + "," + totalCompras + "," + totalRechazos + "\n";

		return mensaje;
	}

	private void calcularTotalCuposDisponiblesyVentasNoConcretadas() {
		for (Propuesta propuesta : propuestas) {
			if (propuesta.getClass() == Atraccion.class) {
				Atraccion atraccion = (Atraccion) propuesta;
				totalCuposDisponibles += atraccion.getCupoDisponible();
				maximoVentasNoConcretadas += atraccion.getCupoDisponible() * atraccion.getCosto();
			}

		}

	}

}
