package laFuerza;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.junit.Test;

public class EscritorIntinerarioUsuarioTest {
	
	
//	@Test
//	public void resumenIntinerarioTest() throws IOException {
//		Atraccion at1 = new Atraccion(150, 2, TipoAtraccion.LADO_OSCURO, 3, "at1");
//		Atraccion at2 = new Atraccion(150, 3, TipoAtraccion.LADO_OSCURO, 5, "at2");
//		LinkedList<Atraccion> atraccionesIncluidas = new LinkedList<Atraccion>();
//		atraccionesIncluidas.add(at1);
//		atraccionesIncluidas.add(at2);
//		Promocion p1 = new PromoPorcentual(TipoAtraccion.LADO_OSCURO, "promo1", "descripcion", atraccionesIncluidas,
//				0.5); // costo
//						// 150
//		p1.setCosto();
//		p1.setTiempoUtilizado();
//		Usuario u1 = new Usuario("u1", TipoAtraccion.LADO_OSCURO, 400, 10); // saldo inicial 400, tiempo disponible 10
//		u1.agregarPropuestaAceptada(p1);
//
//		Atraccion at3 = new Atraccion(50, 1, TipoAtraccion.LADO_OSCURO, 2, "at3");
//		u1.agregarPropuestaAceptada(at3);
//		u1.escribirIntinerario();
//
//		assertEquals(200, u1.getPresupuestoDisponible());
//		assertEquals(4, u1.getTiempoDisponible(), 0);
//
//		// compró promo 1 ( costo 150 monedas, tiempo 5 horas) y at3 (costo 50, horas 1)
//		// total a pagar 200 monedas, total tiempo usado 6 horas
//		// saldo 200 monedas y 4 horas disponibles
//		assertEquals(-1, compararArchivosLineaporLinea("test/salida/u1.txt", "salida/u1.txt"));
//
//		Usuario u2 = new Usuario("u2", TipoAtraccion.LADO_OSCURO, 200, 5); // saldo inicial 400, tiempo disponible 10
//		u2.escribirIntinerario();
//
//		// no compra ninguna propuesta, difiere mensaje inicial y final
//		assertEquals(-1, compararArchivosLineaporLinea("test/salida/u2.txt", "salida/u2.txt"));
//
//	}
	
	
	
	

	private long compararArchivosLineaporLinea(String string, String string2) throws IOException {
		FileReader fl1 = null;
		BufferedReader bf1 = null;
		FileReader fl2 = null;
		BufferedReader bf2 = null;
		long lineNumber = 1;

		try {
			fl1 = new FileReader(string);
			bf1 = new BufferedReader(fl1);
			fl2 = new FileReader(string2);
			bf2 = new BufferedReader(fl2);

			String line1 = "", line2 = "";
			while ((line1 = bf1.readLine()) != null) {
				line2 = bf2.readLine();
				if (line2 == null || !line1.equals(line2)) {
					return lineNumber;
				}
				lineNumber++;
			}
			if (bf2.readLine() == null) {
				return -1;
			} else {
				return lineNumber;
			}
		} catch (IOException e) {
			e.printStackTrace();

		} finally {

			try {
				if (fl1 != null) {
					fl1.close();
				}
				if (fl2 != null) {
					fl2.close();
				}

			} catch (Exception e2) {
				e2.printStackTrace();

			}

		}
		return lineNumber;

	}

}
