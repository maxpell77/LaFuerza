package laFuerza;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Map;
import java.util.Map.Entry;

public abstract class GeneradorResumenSistema {

	private static int totalIngresos = 0;
	private static int totalCompras = 0;
	private static int totalRechazos = 0;
	
	public static void escribirArchivosDetalle2(String mensaje) throws IOException {
		String file = "DetallePropuestas.csv";
		PrintWriter salida = new PrintWriter(new FileWriter("salida/resumen_Sistema/" + file));
		salida.println(mensaje);
		salida.close();
		
	}
	

//	public static void escribirArchivosDetalle(Map<Integer, ArrayList<Propuesta>> propuestasContratadas)
//			throws IOException {
//		String file = "DetallePropuestas.csv";
//		PrintWriter salida = new PrintWriter(new FileWriter("salida/resumen_Sistema/" + file));
//			
//		ArrayList<Propuesta> aux;
//		String menseaje= "";
//		menseaje += "Propuesta, Tipo de Atracción, Ingresos Totales, Compras, Rechazos\n";
//
//		for (Entry<Integer, ArrayList<Propuesta>> cadaPropuesta : propuestasContratadas.entrySet()) {
//
//			aux = cadaPropuesta.getValue();
//
//			for (Propuesta propuesta : aux) {
//				totalIngresos += cadaPropuesta.getKey();
//				totalCompras += propuesta.getCantidadComprada();
//				totalRechazos += propuesta.getCantidadRechazada();
//
//				menseaje += 	propuesta.getNombre() + "," + propuesta.getTipoAtraccion().getNombre() + "," + cadaPropuesta.getKey() + ","
//						+ propuesta.getCantidadComprada() + "," + propuesta.getCantidadRechazada() + "\n";
//
//			}
//
//		}
//		menseaje += "TOTALES" + ",," + totalIngresos + "," + totalCompras + "," + totalRechazos + "\n";
//		salida.println(menseaje);
//		salida.close();
//	}

	public static void escribirArchivoGeneral(int cuposDisponibles, int maximoVentasNoConcretadas, int cuposTotales,
			int cantidadUsuariosCompradores) throws IOException {

		float capacidadOciosa = (float) ((cuposDisponibles * 100) / cuposTotales);
		int ticketPromedio = totalIngresos / cantidadUsuariosCompradores;

		String file = "ResuemGeneral.txt";
		PrintWriter salida = new PrintWriter(new FileWriter("salida/resumen_Sistema/" + file));

		String mensaje = "";

		mensaje += "Resumen general.\n\n";
		mensaje += "Se han realizado ventas a " + cantidadUsuariosCompradores + " usuarios, por un total de "
				+ totalIngresos + " créditos galácticos (ticket promedio de " + ticketPromedio
				+ " créditos galácticos por usuario).\n\n";

		mensaje += "En total se contrataron " + totalCompras + " propuestas y se han rechazado " + totalRechazos
				+ ".\n\n";
		mensaje += "De un máximo de " + cuposTotales + " cupos disponibles, quedaron " + cuposDisponibles
				+ " por vender. Lo que representa una capacidad ociosa del " + capacidadOciosa
				+ "%, equivalente a un máximo de ventas no concretadas de " + maximoVentasNoConcretadas
				+ " créditos galácticos.\n\n";

		mensaje += "¡Que la Fuerza te acompañe!";

		salida.println(mensaje);

		salida.close();

	}

}
