package main;

import java.io.IOException;
import java.util.List;

import laFuerza.LectorArchivosdeEntrada;
import laFuerza.LaFuerza;

public class App {

	public static void main(String[] args) throws IOException {
		
		//mostrar tipo de atraccion cuando se muestra a usuario

		LaFuerza laFuerza = new LaFuerza();

		List<String> atracciones = LectorArchivosdeEntrada.leerArchivo("entrada/atracciones.txt");
		List<String> promociones = LectorArchivosdeEntrada.leerArchivo("entrada/promociones.txt");
		List<String> usuarios = LectorArchivosdeEntrada.leerArchivo("entrada/usuarios.txt");

		laFuerza.agregarAtracciones(atracciones);
		laFuerza.agregarPromociones(promociones);
		laFuerza.agregarUsuarios(usuarios);

		laFuerza.sugerirPropuestasAusuarios();

	}

}
