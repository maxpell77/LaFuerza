package laFuerza;

public enum TipoPromocion {
	PORCENTUAL, ABSOLUTA, AXB
}
