package laFuerza;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public abstract class GeneradorInerarioUsuario {

	public static void escribirIntinerario(Usuario usuario) throws IOException {
		String mensaje = "";

		String resumen = "Tipo de atraccion preferida: " + usuario.getTipoAtraccionPreferida().getNombre() + "\n"
				+ "Saldo Inicial: " + usuario.getPresupuestoInicial() + " créditos galácticos" + "\n"
				+ "Tiempo Disponible Inicial: "
				+ ModificadorFormatoHora.obtenerHoraConFormato(usuario.getTiempoMaximoInicial()) + "\n\n";

		String file = usuario.getNombre() + ".txt";
		PrintWriter salida = new PrintWriter(new FileWriter("salida/intinerarios_Usuarios/" + file));

		if (usuario.getPropuestasContratadas().size() == 0) {
			mensaje += "Muchas gracias " + usuario.getNombre() + " por participar.\n\n";
			mensaje += resumen;
			mensaje += "Lamentablemente no ha adquirido ninguna propuesta.\n\n";
		} else {
			mensaje += "¡Muchas gracias " + usuario.getNombre() + " por compra!\n\n";
			mensaje += resumen;
			mensaje += "Estas son las propuestas contratadas: \n\n";

			for (Propuesta propuesta : usuario.getPropuestasContratadas()) {
				mensaje += propuesta + "\n";
			}

			mensaje += "Total a pagar: " + (usuario.getPresupuestoInicial() - usuario.getPresupuestoDisponible())
					+ " créditos galácticos (saldo disponible: " + usuario.getPresupuestoDisponible()
					+ " créditos galácticos).\n";
			mensaje += "Tiempo utilizado "
					+ ModificadorFormatoHora.obtenerHoraConFormato(
							(usuario.getTiempoMaximoInicial() - usuario.getTiempoDisponible()))
					+ " (tiempo disponible "
					+ ModificadorFormatoHora.obtenerHoraConFormato(usuario.getTiempoDisponible()) + ").\n\n";
			mensaje += "¡Que la Fuerza te acompañe!";
					
			salida.println(mensaje);

		}
		salida.close();
	}

}
